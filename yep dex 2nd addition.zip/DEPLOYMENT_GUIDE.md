# YEP Token dApp - Wix Deployment Guide

## 🎉 Your YEP Token dApp is Ready!

This dApp includes:
- ✅ **Multi-Token Swap** - Swap ANY token on PulseChain (not just YEP!)
- ✅ **Dual Router Support** - Choose between Piteas Aggregator or PulseX Direct
- ✅ **Pre-loaded Popular Tokens** - PLS, WPLS, DAI, HEX, PLSX, INC, YEP
- ✅ **Custom Token Support** - Add any token by pasting its contract address
- ✅ **Real-time Balance Display** - See your token balances instantly
- ✅ **Smart Token Approval** - Automatic approval handling for ERC20 tokens
- ✅ Live token price and stats display
- ✅ Total holders count
- ✅ PulseX liquidity information
- ✅ Token launch date
- ✅ Real-time price comparison between routers
- ✅ "Add to MetaMask" button
- ✅ Wallet connection with PulseChain network
- ✅ **LibertySwap Link** - Direct link to LibertySwap.finance
- ✅ YEP-branded design matching your website

### 🎯 What's Special About Multi-Token Swap?

**Swap Any Token:**
- Choose from popular tokens (PLS, HEX, PLSX, DAI, INC, YEP, etc.)
- Add custom tokens by pasting contract address
- Swap in any direction (Token → Token, PLS → Token, Token → PLS)
- Automatic token approval for ERC20 swaps

**Piteas Aggregator (Recommended):**
- Scans multiple DEXs (PulseX, Phux, 9inch, 9mm, etc.)
- Finds the best price automatically
- Lowest slippage
- Optimal routing algorithm

**PulseX Direct:**
- Direct swap through PulseX
- Faster execution
- Simpler routing
- Good for larger trades

**LibertySwap Integration:**
- Prominent link to LibertySwap.finance under the swap interface
- Easy access to additional trading options

Users can:
- Select any token pair
- Switch between routers to compare prices
- See their balances for selected tokens
- Add custom tokens on-the-fly!

---

## 📋 Step-by-Step Deployment

### Option 1: Deploy to Vercel (Recommended - FREE)

1. **Create a Vercel Account**
   - Go to https://vercel.com
   - Sign up with GitHub, GitLab, or Bitbucket (free)

2. **Upload Your dApp**
   - Click "Add New" → "Project"
   - Click "Import" or drag the `yep-dapp.html` file
   - Rename it to `index.html` before uploading
   - Click "Deploy"

3. **Get Your URL**
   - Vercel will give you a URL like: `https://your-project.vercel.app`
   - Copy this URL - you'll need it for Wix

### Option 2: Deploy to Netlify (Also FREE)

1. **Create Netlify Account**
   - Go to https://netlify.com
   - Sign up for free

2. **Drag & Drop Deploy**
   - Rename `yep-dapp.html` to `index.html`
   - Simply drag the file into Netlify's deploy zone
   - Wait 30 seconds for deployment

3. **Get Your URL**
   - Netlify gives you: `https://your-site.netlify.app`
   - Copy this URL

---

## 🔧 Embedding in Wix

### Method 1: HTML iFrame Element

1. **In Wix Editor:**
   - Click the **"+"** button to add elements
   - Go to **Embed** → **HTML iframe**
   - Drag it to where you want the dApp

2. **Configure the iFrame:**
   - Click on the iframe element
   - Click **"Enter Code"**
   - Paste this code (replace YOUR_URL):

```html
<iframe 
  src="YOUR_VERCEL_OR_NETLIFY_URL" 
  width="100%" 
  height="1200px" 
  frameborder="0"
  allow="clipboard-write"
  style="border-radius: 10px; overflow: hidden;">
</iframe>
```

3. **Adjust Size:**
   - Resize the iframe element to fit your page
   - Recommended minimum height: 1200px

### Method 2: Embed Code Element

1. **In Wix Editor:**
   - Click **"+"** → **Embed** → **Custom Embed**
   - Choose **"Embed a Widget"**

2. **Paste Your Code:**
```html
<div style="width: 100%; max-width: 1400px; margin: 0 auto;">
  <iframe 
    src="YOUR_DEPLOYED_URL"
    width="100%"
    height="1300px"
    frameborder="0"
    allow="clipboard-write"
    scrolling="auto">
  </iframe>
</div>
```

3. **Save and Publish**

---

## 🎨 Customization Options

### Change Colors

Open `yep-dapp.html` and find the `:root` section (around line 8):

```css
:root {
    --yep-green: #39ff14;   /* Change this to your preferred green */
    --yep-blue: #00d9ff;    /* Change this to your preferred blue */
    --yep-purple: #9d00ff;  /* Change this to your preferred purple */
}
```

### Update Token Stats

The dApp currently shows placeholder values. To show real data:

1. **Option A:** Use an API
   - Integrate with DexScreener API for live prices
   - Add your API calls in the `loadTokenData()` function

2. **Option B:** Manual Updates
   - Find the `loadTokenData()` function around line 470
   - Update the placeholder values with your real data

### Change Logo

Replace the logo URL in line 105:
```css
background: url('YOUR_LOGO_URL') center/contain no-repeat;
```

---

## 🔐 Security Notes

- ✅ Users connect their own wallets (no private keys stored)
- ✅ All transactions require user confirmation
- ✅ 2% slippage protection built-in
- ✅ 20-minute deadline on swaps
- ⚠️ Always test with small amounts first!

---

## 🚀 Testing Your dApp

Before going live:

1. **Test on Desktop:**
   - Connect MetaMask
   - Try a small swap (like 1 PLS)
   - Verify "Add to Wallet" button works

2. **Test on Mobile:**
   - Use MetaMask mobile browser
   - Ensure responsive design works
   - Test wallet connection

3. **Check All Features:**
   - [ ] Wallet connects properly
   - [ ] Swap calculates correctly
   - [ ] Transaction executes
   - [ ] Token info displays
   - [ ] "Add to MetaMask" works

---

## 📱 Mobile Optimization

The dApp is fully responsive! On mobile:
- Cards stack vertically
- Swap interface adapts
- Touch-friendly buttons
- Works with MetaMask mobile browser

---

## 🆘 Troubleshooting

### "Please install MetaMask"
- User needs MetaMask extension (desktop) or MetaMask app (mobile)
- Direct them to https://metamask.io

### "Wrong Network"
- dApp will automatically prompt to switch to PulseChain
- Network details are configured automatically

### Swap Fails
- Check if user has enough PLS for gas
- Verify PulseX has liquidity
- Try increasing slippage (future feature)

### iframe Not Showing
- Check if the URL is correct
- Ensure iframe height is at least 1200px
- Clear browser cache

### Router Selection Issues
- If one router fails, try switching to the other
- Piteas aggregator requires multiple DEXs to have liquidity
- PulseX Direct always works if there's liquidity on PulseX

### Different Prices Between Routers
- This is normal! Piteas scans multiple DEXs for best price
- The difference shows how much you save with aggregation
- Always compare both before swapping

### Token Approval Popup
- When swapping ERC20 tokens, you'll see an approval transaction first
- This is normal and required for security
- The dApp requests unlimited approval to save gas on future swaps
- You only need to approve once per token per router

### Custom Token Not Loading
- Verify the contract address is correct
- Make sure the token exists on PulseChain
- Check if it's a valid ERC20 token
- Some tokens may have unusual implementations

---

## 📞 Support

If you need help:
1. Check browser console for errors (F12)
2. Verify PulseChain RPC is working: https://rpc.pulsechain.com
3. Test the dApp directly (not in iframe) first
4. Make sure MetaMask is connected to PulseChain (Chain ID: 369)

---

## 🎯 Next Steps

1. Deploy to Vercel/Netlify
2. Get your deployment URL
3. Embed in Wix using iframe code above
4. Test thoroughly
5. Publish your site!

---

## 💡 Pro Tips

- **Add a "How to Buy" Section:** Guide users through getting PLS first
- **Link to PulseX:** Direct link for users who prefer trading there
- **Add Socials:** Include your Telegram/Twitter in the dApp
- **Show Liquidity Pairs:** List where YEP is tradeable
- **Add Price Charts:** Embed DexScreener chart for visual price data

---

## 📊 Future Enhancements

Want to add more features? You can:
- Integrate live price feeds from DexScreener API
- Add historical price charts
- Show top holders
- Display transaction history
- Add staking functionality
- Include tokenomics visualization

---

**Contract Address:** 0xE08FC6Ce880D36a1167701028c0ae84dc3e82b8f

**YEP on PulseChain - Agreeance Starts Here!** 🚀
